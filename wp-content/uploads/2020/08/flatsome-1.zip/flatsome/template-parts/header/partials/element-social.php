<li class="html header-social-icons ml-0">
	<?php echo do_shortcode('[follow defaults="true" style="'.flatsome_option('follow_style').'"]')?>
</li>